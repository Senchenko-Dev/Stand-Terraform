--liquibase formatted sql
--changeset vkharchikov:1 dbms:postgresql

create sequence if not exists cmp_datasource_id_seq increment by 1 start with 1 cache 10;
create sequence if not exists cmp_schema_id_seq increment by 1 start with 1 cache 10;
create sequence if not exists cmp_exclusion_id_seq increment by 1 start with 1 cache 10;
create sequence if not exists cmp_schema_pair_id_seq increment by 1 start with 1 cache 10;
create sequence if not exists cmp_rule_id_seq increment by 1 start with 1 cache 10;
create sequence if not exists cmp_task_id_seq increment by 1 start with 1 cache 10;
create sequence if not exists cmp_run_id_seq increment by 1 start with 1 cache 10;

create table if not exists cmp_datasource
(
  id int4 primary key,
  ds_type varchar(128) not null,
  ds_name varchar(256) not null,
  ds_uri  varchar(2048) not null,
  pool_size int4
);

create table if not exists cmp_schema
(
  id int4 primary key,
  ds_id int4 not null,
  schema_desc varchar(256) not null,
  schema_name varchar(256) not null,
  schema_json json
);

create unique index if not exists cmp_schema_ds_name_uix on cmp_schema (ds_id, schema_name);
create unique index if not exists cmp_schema_desc_uix on cmp_schema (schema_desc);

create table if not exists cmp_exclusion
(
  id int4 primary key,
  ex_type varchar(256) not null,
  schema_id int4 not null,
  table_pattern varchar(256) not null,
  column_pattern varchar(256)
);

create unique index if not exists cmp_exclusion_uix on cmp_exclusion (schema_id, ex_type, table_pattern, column_pattern);

create table if not exists cmp_schema_pair
(
  id int4 primary key,
  f_schema_id int4 not null,
  s_schema_id int4 not null,
  active  bool default true not null,
  matching json
);

create index if not exists cmp_schema_pair_f_ix on cmp_schema_pair (f_schema_id);
create index if not exists cmp_schema_pair_s_ix on cmp_schema_pair (s_schema_id);

create table if not exists cmp_rule
(
  id int4 primary key,
  name varchar(256) not null,
  batch_size int4 not null,
  max_retries int2 not null,
  pair int4 not null
);

create unique index if not exists cmp_rule_name_uix on cmp_rule (name);
create unique index if not exists cmp_rule_pair_uix on cmp_rule (pair);

create table if not exists cmp_run
(
  id varchar(64) primary key,
  rule_id int4 not null,
  task_type varchar(128) not null,
  created_time timestamptz not null,
  start_time timestamptz not null,
  state_time timestamptz not null,
  state varchar(128) not null,
  tasks int4 not null,
  completed int4 not null,
  retry int4 not null,
  max_retries int4 not null,
  table_name varchar(128),
  from_time timestamptz,
  to_time timestamptz,
  finish_time timestamptz,
  result text,
  error_message text
);

create index if not exists cmp_run_rule_ix on cmp_run (rule_id);

create table if not exists cmp_run_state
(
  run_id varchar(64) primary key,
  state_time timestamptz not null,
  state bytea
);

alter table cmp_schema add constraint cmp_schema_ds_id_fk foreign key (ds_id) references cmp_datasource (id);
alter table cmp_exclusion add constraint cmp_exclusion_schema_id_fk foreign key (schema_id) references cmp_schema (id);
alter table cmp_schema_pair add constraint cmp_cmp_schema_pair_f_schema_id_fk foreign key (f_schema_id) references cmp_schema (id);
alter table cmp_schema_pair add constraint cmp_cmp_schema_pair_s_schema_id_fk foreign key (s_schema_id) references cmp_schema (id);




